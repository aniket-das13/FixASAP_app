

package com.example.myapplication;

public class CusReq {

    private String crphno,crp,crdet,crpin;



    public  CusReq(){}
    public  String getCrphno()
    {
        return crphno;
    }

    public void setCrphno(String Phno) {
        crphno = Phno;
    }
    public  String getCrp()
    {
        return crp;
    }

    public void setCrp(String Crp) {
        crp= Crp;
    }


    public  String getCrdet()
    {
        return crdet ;
    }

    public void setCrdet(String det) {
        crdet= det;
    }

    public  String getCrpin()
    {
        return crpin;
    }

    public void setCrpin(String pin) {
        crpin=pin;
    }



}
